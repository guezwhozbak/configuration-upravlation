ls
cd virtual_fs