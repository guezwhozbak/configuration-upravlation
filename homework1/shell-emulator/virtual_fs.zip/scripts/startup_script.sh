ls
cd virtual_fs
cd dir1
ls
